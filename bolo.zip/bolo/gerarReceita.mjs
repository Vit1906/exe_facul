import axios from 'axios';

const HF_API_KEY = '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'; // Substitua pelo seu token do Hugging Face
const HF_API_URL = 'https://api-inference.huggingface.co/models/gpt2'; // Modelo GPT-2

async function gerarTexto(prompt) {
    try {
        const response = await axios.post(
            HF_API_URL,
            {
                inputs: prompt, // Texto de entrada
                parameters: {
                    max_length: 100, // Tamanho máximo da resposta
                    temperature: 0.7, // Controla a criatividade da resposta
                    do_sample: true, // Amostragem para gerar texto mais diversificado
                }
            },
            {
                headers: {
                    'Authorization': `Bearer ${HF_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        // Exibe a resposta gerada
        console.log(response.data[0].generated_text);
    } catch (error) {
        console.error('Erro ao chamar a API do Hugging Face:', error.response ? error.response.data : error.message);
    }
}

// Exemplo de uso
gerarTexto("Crie uma receita usando os seguintes ingredientes: ovos, farinha, leite.");