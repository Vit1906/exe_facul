require('dotenv').config(); // Carrega as variáveis de ambiente
const express = require('express');
const axios = require('axios');
const path = require('path');
const app = express();
const PORT = 3000;

// Middleware para processar JSON
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir arquivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Rota para a página inicial
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Rota para gerar receitas
app.post('/gerar-receita', async (req, res) => {
    const { ingredientes } = req.body;

    try {
        // Chama a API do DeepSeek (substitua pela URL correta da API)
        const response = await axios.post('https://api.deepseek.com', {
            model: "deepseek-chat", // Substitua pelo modelo correto
            messages: [
                {
                    role: "user",
                    content: `Crie uma receita usando os seguintes ingredientes: ${ingredientes}.`
                }
            ]
        }, {
            headers: {
                'Authorization': `Bearer ${process.env.DEEPSEEK_API_KEY}`,
                'Content-Type': 'application/json'
            }
        });

        // Retorna a receita gerada
        const receita = response.data.choices[0].message.content;
        res.json({ receita });
    } catch (error) {
        console.error('Erro ao chamar a API do DeepSeek:', error);
        res.status(500).json({ error: 'Erro ao gerar a receita' });
    }
});

// Iniciar o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});