document.getElementById('receitaForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const ingredientes = document.getElementById('ingredientes').value;

    try {
        const response = await fetch('/gerar-receita', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ ingredientes })
        });

        const data = await response.json();

        if (data.receita) {
            document.getElementById('receitaTexto').innerText = data.receita;
        } else {
            document.getElementById('receitaTexto').innerText = 'Erro ao gerar a receita.';
        }
    } catch (error) {
        console.error('Erro:', error);
        document.getElementById('receitaTexto').innerText = 'Erro ao conectar ao servidor.';
    }
});